<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\JenisHewan;
use Illuminate\Validation\Rule; 

class JenisHewanController extends Controller
{
    public function index ()
    {
        $jenisHewan = JenisHewan::all();
        return view('admin.jenis-hewan.index', compact('jenisHewan'));
    }

    public function create()
    {
        // Path view diperbaiki (dihapus duplikasi 'create/')
        return view('admin.jenis-hewan.create');
    }

    public function store(Request $request)
    {
        // Panggil validasi tanpa ID (untuk operasi buat baru)
        $validatedData = $this->validateJenisHewan($request); 
        
        // Panggil helper untuk membuat data baru (menggunakan helper Anda)
        $this->createJenisHewan($validatedData);

        return redirect()->route('admin.jenis-hewan.index')
                         ->with('success', 'Jenis hewan berhasil ditambahkan.');
    }

    public function edit(JenisHewan $jenisHewan)
    {
        // Path view diperbaiki (dihapus duplikasi 'edit/')
        return view('admin.jenis-hewan.edit', compact('jenisHewan'));
    }

    public function update(Request $request, JenisHewan $jenisHewan)
    {
        // Panggil validasi dengan ID model (untuk mengecualikan instance saat unique check)
        $validatedData = $this->validateJenisHewan($request, $jenisHewan->idjenis_hewan);

        // Update data dengan data yang sudah divalidasi
        $jenisHewan->update($validatedData);

        return redirect()->route('admin.jenis-hewan.index')
                         ->with('success', 'Jenis hewan berhasil diperbarui.');
    }

    public function destroy(JenisHewan $jenisHewan)
    {
        try {
            $jenisHewan->delete();
            return redirect()->route('admin.jenis-hewan.index')
                             ->with('success', 'Jenis hewan berhasil dihapus.');
        } catch (\Illuminate\Database\QueryException $e) {
            // Menangkap error foreign key constraint
            return redirect()->route('admin.jenis-hewan.index')
                             ->with('error', 'Gagal menghapus jenis hewan karena masih terkait dengan data lain.');
        }
    }

    // Perbaikan: Tambahkan $id = null ke signature dan definisikan $uniqueRule
    private function validateJenisHewan(Request $request, $id = null) 
    {
        // Definisi $uniqueRule untuk mengecualikan ID saat update
        $uniqueRule = Rule::unique('jenis_hewan', 'nama_jenis_hewan');
        if ($id) {
            $uniqueRule->ignore($id, 'idjenis_hewan');
        }

        return $request->validate([
            'nama_jenis_hewan' => [
                'required',
                'string',
                'max:255',
                'min:3',
                $uniqueRule // Menggunakan $uniqueRule yang sudah didefinisikan
            ],
        ], [
            'nama_jenis_hewan.required' => 'Nama jenis hewan tidak boleh kosong.',
            'nama_jenis_hewan.string' =>'Nama jenis hewan harus berupa teks.',
            'nama_jenis_hewan.max' =>'Nama jenis hewan maksimal 255 karakter.',
            'nama_jenis_hewan.min' =>'Nama jenis hewan minimal 3 karakter.',
            'nama_jenis_hewan.unique' => 'Nama jenis hewan sudah ada.',
        ]);
    }

    // helper untuk membuat data baru
    protected function createJenisHewan(array $data)
    {
        try {
            return JenisHewan::create([
                'nama_jenis_hewan' => $this-> formatNamaJenisHewan($data['nama_jenis_hewan']),
            ]);
        } catch (\Exception $e) {
            // Hapus \Exception, cukup throw exception baru atau log
            throw new \Exception('Gagal menyimpan data jenis hewan: ' . $e->getMessage());
        }
    }

    // Helper untuk format nama menjadi Title Case
    protected function formatNamaJenisHewan($nama)
    {
        // Perbaikan: strtolowe seharusnya strtolower
        return trim(ucwords(strtolower($nama))); 
    }    
}

?>