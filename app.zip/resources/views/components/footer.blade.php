<footer>
    <p>&copy; Copyright 2024 Universitas Airlangga. All Rights Reserved</p>
</footer>