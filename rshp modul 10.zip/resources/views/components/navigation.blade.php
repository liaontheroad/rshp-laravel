    <header class="top-nav">
        <nav>
            <img src="https://rshp.unair.ac.id/wp-content/uploads/2024/06/UNIVERSITAS-AIRLANGGA-scaled.webp" alt="Universitas Airlangga Logo" class="left-logo">
            <ul>
                       <li><a href="{{ route('home') }}">Home</a></li>
        <li><a href="{{ route('strukturorg') }}">Struktur Organisasi</a></li>
        <li><a href="{{ route('layanan') }}">Layanan Umum</a></li>
        <li><a href="{{ route('visimisi') }}">Visi Misi</a></li>
                 <li><a href="#" class="btn-login">Login</a></li>
            </ul>
        </nav>
    </header>