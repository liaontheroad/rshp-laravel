

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h4 class="mb-0">Selamat Datang, <?php echo e(session('user_name')); ?>!</h4>
                    <a href="<?php echo e(route('logout')); ?>" class="btn btn-danger btn-sm"
                       onclick="event.preventDefault();
                                     document.getElementById('logout-form-dashboard').submit();">
                        Logout
                    </a>
                </div>
  
                <div class="card-body">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>

                    <p>Anda login sebagai <strong><?php echo e(session('user_role_name')); ?></strong>. Silakan kelola registrasi pasien melalui menu di bawah ini.</p>

                    <hr>

                    <h5><i class="fas fa-database"></i> Menu Registrasi </h5>
                    <div class="row mt-3">
                          <div class="col-md-4 mb-3">
                            <a href="<?php echo e(route('resepsionis.pendaftaran')); ?>" class="btn btn-outline-primary btn-block w-100">Jenis Hewan</a>
                        </div>
            
                    </div>
                </div>

                <form id="logout-form-dashboard" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                    <?php echo csrf_field(); ?>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\slamet riyadi\OneDrive - Universitas Airlangga\SEM 3\Framework (Prak ver)\Laravel Project\RSHP\resources\views/resepsionis/dashboard-resepsionis.blade.php ENDPATH**/ ?>