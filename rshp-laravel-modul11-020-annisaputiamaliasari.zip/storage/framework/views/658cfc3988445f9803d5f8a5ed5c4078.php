

<?php $__env->startSection('content'); ?>
<div class="page-container">
    <div class="page-header">
        <h1>Manajemen Data Pemilik</h1>
        <p>Kelola data lengkap pemilik hewan peliharaan.</p>
    </div>

    <div class="main-content">
        <?php if(session('success')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        
        <?php if(session('error')): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>

        
        <a href="<?php echo e(route('admin.pemilik.create')); ?>" class="add-btn">
            <i class="fas fa-user-plus"></i> Tambah Pemilik
        </a>

        <table class="data-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nama Pemilik</th>
                    <th>Nomor HP</th>
                    <th>Email</th>
                    <th>Alamat</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $pemilik; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($item->idpemilik); ?></td>
                    <td><?php echo e($item->nama_pemilik); ?></td>
                    <td><?php echo e($item->no_hp); ?></td>
                    <td><?php echo e($item->email ?? '-'); ?></td>
                    <td><?php echo e(Str::limit($item->alamat, 50)); ?></td>
                    <td class="action-buttons">
                        
                        <a href="<?php echo e(route('admin.pemilik.edit', $item->idpemilik)); ?>" class="edit-btn">
                            <i class="fas fa-edit"></i> Edit
                        </a>

                        
                        <form action="<?php echo e(route('admin.pemilik.destroy', $item->idpemilik)); ?>" method="POST" style="display:inline-block;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="delete-btn" onclick="return confirm('Apakah Anda yakin ingin menghapus data pemilik <?php echo e($item->nama_pemilik); ?>? Tindakan ini tidak dapat dibatalkan.')">
                                <i class="fas fa-trash"></i> Hapus
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6" style="text-align: center;">Tidak ada data pemilik yang terdaftar.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\slamet riyadi\OneDrive - Universitas Airlangga\SEM 3\Framework (Prak ver)\Laravel Project\RSHP\resources\views/admin/pemilik/index.blade.php ENDPATH**/ ?>