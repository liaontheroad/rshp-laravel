<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RSHP UNAIR - Rumah Sakit Hewan Pendidikan</title>
     <link rel="stylesheet" href="<?php echo e(asset('css/site.css')); ?>">
</head> 
<body>

<?php if (isset($component)) { $__componentOriginalcd6dfa97cd4704d24f53bf5968f88fee = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcd6dfa97cd4704d24f53bf5968f88fee = $attributes; } ?>
<?php $component = App\View\Components\Navigation::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('navigation'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Navigation::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcd6dfa97cd4704d24f53bf5968f88fee)): ?>
<?php $attributes = $__attributesOriginalcd6dfa97cd4704d24f53bf5968f88fee; ?>
<?php unset($__attributesOriginalcd6dfa97cd4704d24f53bf5968f88fee); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcd6dfa97cd4704d24f53bf5968f88fee)): ?>
<?php $component = $__componentOriginalcd6dfa97cd4704d24f53bf5968f88fee; ?>
<?php unset($__componentOriginalcd6dfa97cd4704d24f53bf5968f88fee); ?>
<?php endif; ?>

    <!-- Hero Section -->
    <div class="hero">
        <div class="hero-content">
            <h1>
                Pengalaman Terbaik<br>
                <span>Layanan Hewan</span>
            </h1>
              <p>
          Rumah Sakit Hewan Pendidikan Universitas Airlangga berinovasi untuk selalu meningkatkan kualitas pelayanan,
          maka dari itu Rumah Sakit Hewan Pendidikan Universitas Airlangga mempunyai fitur pendaftaran online yang
          mempermudah untuk mendaftarkan hewan kesayangan anda
        </p>
            <div class="hero-buttons">
                <a href="https://youtu.be/rCfvZPECZvE" class="btn-primary">Daftar Sekarang</a>
                <button class="btn-video">
                    <div class="play-icon">▶</div>
                    <span>Tonton Video</span>
                </button>
            </div>
        </div>

        <div class="hero-image">
            <div class="image-wrapper">
                <div class="main-circle">
                    <img src="https://images.unsplash.com/photo-1516734212186-a967f81ad0d7?w=400&h=400&fit=crop" alt="Dokter Hewan" class="vet-photo">
                </div>
                <img src="https://images.unsplash.com/photo-1583337130417-3346a1be7dee?w=120&h=120&fit=crop" alt="Anjing" class="pet-small pet-1">
                <img src="https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?w=120&h=120&fit=crop" alt="Kucing" class="pet-small pet-2">
            </div>
        </div>
    </div>

    <!-- Stats Section -->
    <div class="stats">
        <div class="stat-card">
            <div class="stat-number">24/7</div>
            <div class="stat-label">Layanan Siaga</div>
        </div>
        <div class="stat-card">
            <div class="stat-number">4.9</div>
            <div class="stat-label">Rating Layanan</div>
        </div>
    </div>

    <!-- Progress Section -->
    <div class="progress-section">
        <h2>Kemajuan Kami Memberikan<br>Perawatan Terbaik</h2>
        <p>
            Dengan tim dokter hewan berpengalaman dan teknologi medis terkini, kami berkomitmen memberikan perawatan kesehatan hewan yang berkualitas tinggi untuk kesejahteraan hewan kesayangan Anda.
        </p>
    </div>

    <!-- Footer -->
    <footer>
        <p>&copy; Copyright 2024 Universitas Airlangga. All Rights Reserved</p>
    </footer>

</body>
</html><?php /**PATH C:\Users\slamet riyadi\OneDrive - Universitas Airlangga\SEM 3\Framework (Prak ver)\Laravel Project\RSHP\resources\views/site/home.blade.php ENDPATH**/ ?>