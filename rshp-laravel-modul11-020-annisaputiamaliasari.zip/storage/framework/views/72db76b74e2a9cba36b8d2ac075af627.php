<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Struktur Organisasi - RSHP UNAIR</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/site.css')); ?>">
</head>
<body>

    <?php if (isset($component)) { $__componentOriginalcd6dfa97cd4704d24f53bf5968f88fee = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalcd6dfa97cd4704d24f53bf5968f88fee = $attributes; } ?>
<?php $component = App\View\Components\Navigation::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('navigation'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Navigation::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalcd6dfa97cd4704d24f53bf5968f88fee)): ?>
<?php $attributes = $__attributesOriginalcd6dfa97cd4704d24f53bf5968f88fee; ?>
<?php unset($__attributesOriginalcd6dfa97cd4704d24f53bf5968f88fee); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcd6dfa97cd4704d24f53bf5968f88fee)): ?>
<?php $component = $__componentOriginalcd6dfa97cd4704d24f53bf5968f88fee; ?>
<?php unset($__componentOriginalcd6dfa97cd4704d24f53bf5968f88fee); ?>
<?php endif; ?>

    <main class="page-container">
        <header class="page-header-alt">
            <h1>Struktur Organisasi</h1>
            <p>Struktur Organisasi Rumah Sakit Hewan Pendidikan Universitas Airlangga.</p>
        </header>

        <section class="structure-section">
            <div class="org-chart">
                <!-- Tingkat Direktur -->
                <div class="org-level">
                    <div class="org-node director">
                        <img src="<?php echo e(asset('images/Direktur.png')); ?>" alt="Direktur" class="org-chart-image">
                        <div class="node-content">
                            <strong>Direktur</strong>
                            <span>Dr, Ira Sari Yudaniayanti, M.P., drh.</span>
                        </div>
                    </div>
                </div>

                <!-- Garis penghubung -->
                

                <!-- Tingkat Manajer -->
                <div class="org-level">
                    <div class="org-node">
                        <img src="<?php echo e(asset('images/Wakil-Direktur-1.png')); ?>" alt="Wakil Direktur 1" class="org-chart-image">
                        <div class="node-content">
                            <strong>Wakil Direktur 1 <br> (Pelayanan Medis, Pendidikan dan penelitian)</strong>
                            <span>Dr. Nusdianto Triakoso, M.P., drh.</span>
                        </div>
                    </div>
                    <div class="org-node">
                        <img src="<?php echo e(asset('images/Wakil-Direktur-2.png')); ?>" alt="Wakil Direktur 2" class="org-chart-image">
                        <div class="node-content">
                            <strong>Wakil Direktur 2 <br> (Sumber daya, Sarana Prasarana dan Keuangan)</strong>
                            <span>Dr. Miyayu Soneta S,. M.Vet., drh.</span>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <?php if (isset($component)) { $__componentOriginal8a8716efb3c62a45938aca52e78e0322 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8a8716efb3c62a45938aca52e78e0322 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8a8716efb3c62a45938aca52e78e0322)): ?>
<?php $attributes = $__attributesOriginal8a8716efb3c62a45938aca52e78e0322; ?>
<?php unset($__attributesOriginal8a8716efb3c62a45938aca52e78e0322); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8a8716efb3c62a45938aca52e78e0322)): ?>
<?php $component = $__componentOriginal8a8716efb3c62a45938aca52e78e0322; ?>
<?php unset($__componentOriginal8a8716efb3c62a45938aca52e78e0322); ?>
<?php endif; ?>

</body>
</html><?php /**PATH C:\Users\slamet riyadi\OneDrive - Universitas Airlangga\SEM 3\Framework (Prak ver)\Laravel Project\RSHP\resources\views/site/strukturorg.blade.php ENDPATH**/ ?>