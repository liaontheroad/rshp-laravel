

<?php $__env->startSection('content'); ?>
<div class="page-container">
    <div class="page-header">
        <h1>Manajemen Kode Tindakan & Terapi</h1>
        <p>Kelola kode-kode yang digunakan untuk tindakan dan terapi klinis.</p>
    </div>

    <div class="main-content">
        <?php if(session('success')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        
        <?php if(session('error')): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>

        
        <a href="<?php echo e(route('admin.kode-tindakan-terapi.create')); ?>" class="add-btn">
            <i class="fas fa-plus"></i> Tambah Kode Baru
        </a>

        <table class="data-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Kode</th>
                    <th>Deskripsi Tindakan</th>
                    <th>Kategori Hewan</th>
                    <th>Kategori Klinis</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $kodeTindakanTerapi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($item->idkode_tindakan_terapi); ?></td>
                    <td><strong><?php echo e($item->kode); ?></strong></td>
                    <td><?php echo e($item->deskripsi); ?></td>
                    <td><?php echo e($item->kategori->nama_kategori ?? 'N/A'); ?></td>
                    <td><?php echo e($item->kategoriKlinis->nama_kategori_klinis ?? 'N/A'); ?></td>
                    <td class="action-buttons">
                        
                        <a href="<?php echo e(route('admin.kode-tindakan-terapi.edit', $item->idkode_tindakan_terapi)); ?>" class="edit-btn">
                            <i class="fas fa-edit"></i> Edit
                        </a>

                        
                        <form action="<?php echo e(route('admin.kode-tindakan-terapi.destroy', $item->idkode_tindakan_terapi)); ?>" method="POST" style="display:inline-block;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="delete-btn" onclick="return confirm('Apakah Anda yakin ingin menghapus kode <?php echo e($item->kode); ?>? Tindakan ini tidak dapat dibatalkan.')">
                                <i class="fas fa-trash"></i> Hapus
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6" style="text-align: center;">Tidak ada data kode tindakan/terapi.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\slamet riyadi\OneDrive - Universitas Airlangga\SEM 3\Framework (Prak ver)\Laravel Project\RSHP\resources\views/admin/kode-tindakan-terapi/index.blade.php ENDPATH**/ ?>