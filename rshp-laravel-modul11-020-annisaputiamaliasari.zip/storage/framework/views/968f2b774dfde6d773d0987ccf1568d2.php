 

<?php $__env->startPush('styles'); ?>
<style>
    .action-buttons form {
        display: inline-block;
    }
    .action-buttons .edit-btn,
    .action-buttons .delete-btn {
        padding: 6px 12px;
        border-radius: 5px;
        text-decoration: none;
        color: white;
        font-size: 14px;
        font-weight: bold;
        margin-right: 5px;
        display: inline-block;
        transition: all 0.3s ease;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('title', 'Daftar Jenis Hewan'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="page-header">
        <h1>Manajemen Jenis Hewan</h1>
        <p>Kelola data master untuk kategori utama hewan.</p>
    </div>

    
    <?php if(session('success')): ?>
        <div class="alert alert-success" style="margin-top: 20px;"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger" style="margin-top: 20px;"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    
    <a href="<?php echo e(route('admin.jenis-hewan.create')); ?>" class="add-btn">
        Tambah Jenis Hewan
    </a>

    
    <table class="data-table">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Jenis Hewan</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            
            <?php $__currentLoopData = $jenisHewan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $hewan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                
                <td><?php echo e($index + 1); ?></td> 
                
                
                <td><?php echo e($hewan->nama_jenis_hewan); ?></td>
                
                
                <td class="action-buttons">
                    
                    <a href="<?php echo e(route('admin.jenis-hewan.edit', $hewan->idjenis_hewan)); ?>" class="edit-btn">
                        Edit
                    </a>
                    
                    
                    
                    <form action="<?php echo e(route('admin.jenis-hewan.destroy', $hewan->idjenis_hewan)); ?>" method="POST" onsubmit="return confirm('Anda yakin ingin menghapus jenis hewan ini?');" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="delete-btn">
                            Hapus
                        </button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <?php if($jenisHewan->isEmpty()): ?>
                <tr>
                    <td colspan="3" style="text-align: center;">Tidak ada data jenis hewan.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\slamet riyadi\OneDrive - Universitas Airlangga\SEM 3\Framework (Prak ver)\Laravel Project\RSHP\resources\views/admin/jenis-hewan/index.blade.php ENDPATH**/ ?>