

<?php $__env->startSection('content'); ?>
<div class="page-container">
    <div class="page-header">
        <h1>Manajemen Ras Hewan</h1>
        <p>Kelola berbagai ras dari setiap jenis hewan.</p>
    </div>

    <div class="main-content">
        <?php if(session('success')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        
        <?php if(session('error')): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>

        <a href="<?php echo e(route('admin.ras-hewan.create')); ?>" class="add-btn">
            <i class="fas fa-plus"></i> Tambah Ras Hewan
        </a>

        <table class="data-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nama Ras</th>
                    <th>Jenis Hewan</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $rasHewan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ras): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($ras->idras_hewan); ?></td>
                    <td><?php echo e($ras->nama_ras); ?></td>
                    <td><?php echo e($ras->jenis->nama_jenis_hewan ?? 'N/A'); ?></td>
                    <td class="action-buttons">
                        <a href="<?php echo e(route('admin.ras-hewan.edit', $ras->idras_hewan)); ?>" class="edit-btn">
                            <i class="fas fa-edit"></i> Edit
                        </a>

                        <form action="<?php echo e(route('admin.ras-hewan.destroy', $ras->idras_hewan)); ?>" method="POST" style="display:inline-block;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="delete-btn" onclick="return confirm('Apakah Anda yakin ingin menghapus ras <?php echo e($ras->nama_ras); ?>? Tindakan ini tidak dapat dibatalkan.')">
                                <i class="fas fa-trash"></i> Hapus
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4" style="text-align: center;">Tidak ada data ras hewan.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\slamet riyadi\OneDrive - Universitas Airlangga\SEM 3\Framework (Prak ver)\Laravel Project\RSHP\resources\views/admin/ras-hewan/index.blade.php ENDPATH**/ ?>