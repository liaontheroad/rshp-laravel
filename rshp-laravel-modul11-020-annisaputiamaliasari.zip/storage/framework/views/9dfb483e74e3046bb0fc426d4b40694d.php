

<?php $__env->startSection('content'); ?>
<div class="page-container">
    <div class="page-header">
        <h1>Manajemen Data Pasien (Pets)</h1>
        <p>Kelola data lengkap hewan peliharaan yang terdaftar.</p>
    </div>

    <div class="main-content">
        <?php if(session('success')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        
        <?php if(session('error')): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>

        
        <a href="<?php echo e(route('admin.pets.create')); ?>" class="add-btn">
            <i class="fas fa-paw"></i> Tambah Pasien Baru
        </a>

        <table class="data-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nama Pasien</th>
                    <th>Pemilik</th>
                    <th>Jenis</th>
                    <th>Ras</th>
                    <th>Kelamin</th>
                    <th>Tanggal Lahir</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $pets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($pet->idpet); ?></td>
                    <td><strong><?php echo e($pet->nama_pet); ?></strong></td>
                    <td><?php echo e($pet->pemilik->nama_pemilik ?? 'N/A'); ?></td>
                    <td><?php echo e($pet->jenisHewan->nama_jenis_hewan ?? 'N/A'); ?></td>
                    <td><?php echo e($pet->rasHewan->nama_ras ?? 'N/A'); ?></td>
                    <td><?php echo e($pet->jenis_kelamin); ?></td>
                    <td><?php echo e($pet->tanggal_lahir); ?></td>
                    <td class="action-buttons">
                        
                        <a href="<?php echo e(route('admin.pets.edit', $pet->idpet)); ?>" class="edit-btn">
                            <i class="fas fa-edit"></i> Edit
                        </a>

                        
                        <form action="<?php echo e(route('admin.pets.destroy', $pet->idpet)); ?>" method="POST" style="display:inline-block;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="delete-btn" onclick="return confirm('Apakah Anda yakin ingin menghapus data pasien <?php echo e($pet->nama_pet); ?>? Tindakan ini tidak dapat dibatalkan jika ada rekam medis terkait.')">
                                <i class="fas fa-trash"></i> Hapus
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="8" style="text-align: center;">Tidak ada data pasien yang terdaftar.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\slamet riyadi\OneDrive - Universitas Airlangga\SEM 3\Framework (Prak ver)\Laravel Project\RSHP\resources\views/admin/pets/index.blade.php ENDPATH**/ ?>