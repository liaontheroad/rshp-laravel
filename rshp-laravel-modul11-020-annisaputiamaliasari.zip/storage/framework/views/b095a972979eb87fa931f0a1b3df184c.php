    <header class="top-nav">
        <nav>
            <img src="https://rshp.unair.ac.id/wp-content/uploads/2024/06/UNIVERSITAS-AIRLANGGA-scaled.webp" alt="Universitas Airlangga Logo" class="left-logo">
            <ul>
                       <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
        <li><a href="<?php echo e(route('strukturorg')); ?>">Struktur Organisasi</a></li>
        <li><a href="<?php echo e(route('layanan')); ?>">Layanan Umum</a></li>
        <li><a href="<?php echo e(route('visimisi')); ?>">Visi Misi</a></li>
                 <li><a href="#" class="btn-login">Login</a></li>
            </ul>
        </nav>
    </header><?php /**PATH C:\Users\slamet riyadi\OneDrive - Universitas Airlangga\SEM 3\Framework (Prak ver)\Laravel Project\RSHP\resources\views/components/navigation.blade.php ENDPATH**/ ?>