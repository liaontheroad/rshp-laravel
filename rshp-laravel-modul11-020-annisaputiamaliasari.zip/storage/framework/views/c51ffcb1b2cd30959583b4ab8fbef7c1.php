

<?php $__env->startPush('styles'); ?>
<style>
    .page-header {
        background: linear-gradient(135deg, #6588e8, #4a6fc4);
        color: white;
        padding: 30px;
        border-radius: 10px;
        margin-bottom: 30px;
        text-align: center;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    }
    .page-header h1 { margin: 0; font-size: 28px; }
    .page-header p { margin: 10px 0 0 0; opacity: 0.9; }
    .data-table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        background-color: white;
        border-radius: 10px;
        overflow: hidden;
    }
    .data-table th, .data-table td {
        padding: 12px 15px;
        border-bottom: 1px solid #ddd;
        text-align: left;
    }
    .data-table thead tr {
        background-color: #f2f2f2;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="page-header">
        <h1>Data Hewan Peliharaan Saya</h1>
        <p>Berikut adalah daftar hewan peliharaan yang terdaftar atas nama Anda.</p>
    </div>

    <table class="data-table">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Peliharaan</th>
                <th>Jenis Hewan</th>
                <th>Ras</th>
                <th>Tanggal Lahir</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $pets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($pet->nama_pet); ?></td>
                    <td><?php echo e($pet->rasHewan->jenis->nama_jenis_hewan ?? 'N/A'); ?></td>
                    <td><?php echo e($pet->rasHewan->nama_ras_hewan ?? 'N/A'); ?></td>
                    <td><?php echo e(\Carbon\Carbon::parse($pet->tanggal_lahir)->format('d F Y')); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="5" class="text-center">Anda belum memiliki data hewan peliharaan yang terdaftar.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\slamet riyadi\OneDrive - Universitas Airlangga\SEM 3\Framework (Prak ver)\Laravel Project\RSHP\resources\views/pemilik/index.blade.php ENDPATH**/ ?>