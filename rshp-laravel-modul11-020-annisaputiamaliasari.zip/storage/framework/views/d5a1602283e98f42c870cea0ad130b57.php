

<?php $__env->startSection('content'); ?>
<div class="page-container">
    <div class="page-header">
        <h1>Manajemen Kategori Hewan</h1>
        <p>Kelola kategori umum untuk hewan peliharaan.</p>
    </div>

    <div class="main-content">
        <?php if(session('success')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        
        <?php if(session('error')): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>

        
        <a href="<?php echo e(route('admin.kategori-hewan.create')); ?>" class="add-btn">
            <i class="fas fa-plus"></i> Tambah Kategori
        </a>

        <table class="data-table">
            <thead>
                <tr>
                    <th>NO</th>
                    <th>Nama Kategori</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($index + 1); ?></td>
                    <td><?php echo e($item->nama_kategori); ?></td>
                    <td class="action-buttons">
                        
                        <a href="<?php echo e(route('admin.kategori-hewan.edit', $item->idkategori)); ?>" class="edit-btn">
                            <i class="fas fa-edit"></i> Edit
                        </a>

                        
                        <form action="<?php echo e(route('admin.kategori-hewan.destroy', $item->idkategori)); ?>" method="POST" style="display:inline-block;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="delete-btn" onclick="return confirm('Apakah Anda yakin ingin menghapus kategori <?php echo e($item->nama_kategori); ?>? Tindakan ini tidak dapat dibatalkan jika masih ada relasi data.')">
                                <i class="fas fa-trash"></i> Hapus
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="3" style="text-align: center;">Tidak ada data kategori hewan.</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\slamet riyadi\OneDrive - Universitas Airlangga\SEM 3\Framework (Prak ver)\Laravel Project\RSHP\resources\views/admin/kategori/index.blade.php ENDPATH**/ ?>