<footer>
    <p>&copy; Copyright 2024 Universitas Airlangga. All Rights Reserved</p>
</footer><?php /**PATH C:\Users\slamet riyadi\OneDrive - Universitas Airlangga\SEM 3\Framework (Prak ver)\Laravel Project\RSHP\resources\views/components/footer.blade.php ENDPATH**/ ?>