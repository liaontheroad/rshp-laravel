<div class="card">
    <div class="card-header">
        Menu Navigasi
    </div>
    <div class="card-body">
        <ul class="nav flex-column">

            
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('home')); ?>">Home</a>
            </li>

            
            <?php if(session('user_role') == 1): ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('admin.dashboard')); ?>">Admin Dashboard</a>
                </li>
                
                
            <?php endif; ?>

            
            <?php if(session('user_role') == 2): ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('dokter.dashboard')); ?>">Dokter Dashboard</a>
                </li>
                
            <?php endif; ?>

            
            <?php if(session('user_role') == 3): ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('perawat.dashboard')); ?>">Perawat Dashboard</a>
                </li>
                
            <?php endif; ?>

            
            <?php if(session('user_role') == 4): ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('resepsionis.dashboard')); ?>">Resepsionis Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('resepsionis.pendaftaran')); ?>">Pendaftaran</a>
                </li>
            <?php endif; ?>

            
            <?php if(session('user_role') == 5): ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('pemilik.dashboard')); ?>">Pemilik Dashboard</a>
                </li>
                
            <?php endif; ?>
        </ul>
    </div>
</div><?php /**PATH C:\Users\slamet riyadi\OneDrive - Universitas Airlangga\SEM 3\Framework (Prak ver)\Laravel Project\RSHP\resources\views/layouts/_sidebar.blade.php ENDPATH**/ ?>