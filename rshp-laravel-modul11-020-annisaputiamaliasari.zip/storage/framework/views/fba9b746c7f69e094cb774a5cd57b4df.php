

<?php $__env->startSection('title', 'Edit Ras Hewan'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-container">
    
    <div class="form-container">
        <h1>Edit Ras Hewan: <?php echo e($rasHewan->nama_ras); ?></h1>
        
        <a href="<?php echo e(route('admin.ras-hewan.index')); ?>" class="back-link">
            <i class="fas fa-arrow-left"></i> Kembali ke Daftar Ras
        </a>

        
        <?php if(session('error')): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('admin.ras-hewan.update', $rasHewan->idras_hewan)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?> 

            
            <div class="form-group">
                <label for="nama_ras">Nama Ras Hewan <span class="text-danger">*</span></label>
                <input
                    type="text"
                    id="nama_ras"
                    name="nama_ras"
                    
                    value="<?php echo e(old('nama_ras', $rasHewan->nama_ras)); ?>" 
                    placeholder="Masukkan nama ras hewan"
                    required
                >
                <?php $__errorArgs = ['nama_ras'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div class="form-group">
                <label for="idjenis_hewan">Jenis Hewan <span class="text-danger">*</span></label>
                <select id="idjenis_hewan" name="idjenis_hewan" required>
                    <option value="">Pilih Jenis Hewan</option>
                    <?php $__currentLoopData = $jenisHewan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jenis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option 
                            value="<?php echo e($jenis->idjenis_hewan); ?>" 
                            
                            <?php echo e(old('idjenis_hewan', $rasHewan->idjenis_hewan) == $jenis->idjenis_hewan ? 'selected' : ''); ?>

                        >
                            <?php echo e($jenis->nama_jenis_hewan); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <?php $__errorArgs = ['idjenis_hewan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <button type="submit" class="btn-submit">
                <i class="fas fa-save"></i> Perbarui Data
            </button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\slamet riyadi\OneDrive - Universitas Airlangga\SEM 3\Framework (Prak ver)\Laravel Project\RSHP\resources\views/admin/ras-hewan/edit.blade.php ENDPATH**/ ?>